 export let multi = (a,b) =>{
    return a*b + " Is Comming From The mul File";
 }