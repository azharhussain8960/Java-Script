
export let div = (a,b)=>{
     return (a/b + " Is Comming From The mul File")
}