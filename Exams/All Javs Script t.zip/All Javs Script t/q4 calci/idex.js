import { add } from "./add.js";
import { sunstraction } from "./sub.js";
import { multi } from "./mul.js";
import { div } from "./div.js";

console.log(add(6,3));
console.log(sunstraction(10,5));
console.log(multi(5,6));
console.log(div(10,2));

