


 export let getage = (x,y)=>{
    return ` Hello ${x} ${y} How Are You!`
}