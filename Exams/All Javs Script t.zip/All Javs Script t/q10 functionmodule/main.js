import { getage } from "./func1.js";
import { getrndm } from "./func2.js";
import {getgreet} from "./func3.js"
import { gret } from "./func3.js";
import {x} from "./func4.js"
import {togetlength} from "./func4.js"
import { myfunc } from "./func5.js";

console.log(getage("Azhar","Hussain"));
getrndm()
getgreet(`Hello ${gret} Good Morning` )

togetlength(`${x}`)
myfunc()
