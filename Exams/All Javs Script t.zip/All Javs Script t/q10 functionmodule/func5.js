

export let myfunc = ()=>{
    console.log("Hello, World!");
}