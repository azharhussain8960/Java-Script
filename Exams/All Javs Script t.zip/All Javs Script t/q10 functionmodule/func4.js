

export let x =+prompt("Enter Any Word To Find Its Length")

export let togetlength = (a)=>{
console.log(a.length);

}
