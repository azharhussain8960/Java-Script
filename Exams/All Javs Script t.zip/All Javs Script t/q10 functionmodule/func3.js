

export let gret =prompt("Greet")

export let getgreet = (gret)=>{
   console.log(gret);
   
}